<div id="sidebar">
	<link rel="stylesheet" type="text/css" href="images/spon slider/engine20/style.css" />
	
<div id="wowslider-container20" style="border:1px solid #ccc;">
	<div class="ws_images"><ul>
<li><img src="images/spon slider/data20/images/sfslide.jpg" alt="sfslide" title="sfslide" id="wows2_0"/></li>
<li><img src="images/spon slider/data20/images/debsoc.jpg" alt="debsoc" title="debsoc" id="wows2_1"/></li>
<li><img src="images/spon slider/data20/images/sponlogo.jpg" alt="sponlogo" title="sponlogo" id="wows2_2"/></li>
</ul></div>

	<div class="ws_shadow"></div>
	</div>
	<script type="text/javascript" src="images/spon slider/engine20/wowslider.js"></script>
	<script type="text/javascript" src="images/spon slider/engine20/script.js"></script>
<br>
<br>
<p style="text-align:center;"><b style="font-size:20px;">24th January, 2013</b></p>
<iframe src="countdown/index.html" frameborder="0" width="225" height="61" scrolling="no" style="margin-left:20px"></iframe>
<!--<h3>Countdown to IITKGPMUN</h3>
<div class="hasCountdown" id="countdown"><div id="timer"><hr><div id="timer_days" class="timer_numbers">00</div><div id="timer_hours" class="timer_numbers">00</div><div id="timer_mins" class="timer_numbers">00</div><div id="timer_seconds" class="timer_numbers">00</div><div id="timer_labels"><div id="timer_days_label" class="timer_labels">days</div><div id="timer_hours_label" class="timer_labels">hours</div><div id="timer_mins_label" class="timer_labels">mins</div><div id="timer_seconds_label" class="timer_labels">secs</div></div></div></div>
-->
<script type='text/javascript'>
$('#c1 div').removeAttr('title');
$('#c1 div').unbind('click');
</script>
<br>
<br>
<br>
<ul>
<li>
<h2>Announcements</h2>
<ul style="margin:10px;font-size: 13px;">
<li>
<i>
Executive Board Applications are now open. 
</i>
</li>
</ul>
</li>
</ul>
<!--
<ul>
<li>
<h2>Documentary</h2>
<ul>
<li>
<object height="315" width="560">
<param name="movie" value="http://www.youtube.com/v/vnNH6tBRpm0?version=3&amp;amp;hl=en_US">
<param name="allowFullScreen" value="true">
<param name="allowscriptaccess" value="always">
<embed allowfullscreen="true" allowscriptaccess="always" src="awards_files/vnNH6tBRpm0" style="margin-right:10px;" type="application/x-shockwave-flash" height="147" width="260">
</object>
</li>
</ul>
</li>
</ul>
-->
<ul>
<li>
<h2>Get Social</h2>
<ul style="margin:10px;">
<li>
Keep in touch with the MUN
<a href="http://www.facebook.com/groups/iitkgpmun/" target="_blank">in the facebook group</a>
</li>
<li>
<a href="http://www.facebook.com/iitkgpmun" target="_blank"><img width="50px;" src="images/fb.jpg"></a>
<a href="http://twitter.com/IITKGPMUN13" target="_blank"><img width="50px;" src="images/tw.png"></a>
<a href="http://youtube.com/user/iitkgpmun" target="_blank"><img width="50px;" src="images/youtube-thumbnail.jpg"></a>
<a href="mailto:iitkgpmun13@gmail.com" target="_blank"><img width="50px;" src="images/Email.png"></a>
</li>
</ul>
</li>
</ul>
</div>
<div class="clr"></div>
</div>
<div class="clr"></div>
</div>
<div class="clr"></div>
<div class="clr"></div>
<div id="footer">
© IITKGPMUN 2013 | Organized by
<a href="http://www.facebook.com/springfest.iitkgp" style="text-decoration:none;" target="_blank">Spring Fest</a>
and
<a href="http://www.facebook.com/debsoc.kgp" style="text-decoration:none;" target="_blank">Debating Society, IIT Kharagpur</a>
| Site modified by
<a href="http://www.facebook.com/dheeraj143" style="text-decoration:none;" target="_blank">Dheeraj Avvari</a> and <a href="https://www.facebook.com/nadeemskv" style="text-decoration:none;" target="_blank">Nadeem Shaik</a>
| Courtesy
<a href="http://www.facebook.com/sricharan92" style="text-decoration:none;" target="_blank">Sricharan Sunder</a>
</div>
<script type="text/javascript">
if (typeof gaJsHost == 'undefined') {
  var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
  document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
}
</script><script src="awards_files/ga.js" type="text/javascript"></script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-36221008-1");
pageTracker._trackPageview();
} catch(err) {}</script>


<script>
  //<![CDATA[
    
  //]]>
</script>
</body></html>