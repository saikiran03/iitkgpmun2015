<?php include_once('headerq.php'); ?>
<a href="iitkgpmu12.php">IITKGPMUN&#146;12</a>
</h2>
<marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
<a href='#' onclick='load("1");'><img src='images/iitkgpmun12/1.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_1'/></a>
<a href='#' onclick='load("2");'><img src='images/iitkgpmun12/2.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_2'/></a>
<a href='#' onclick='load("3");'><img src='images/iitkgpmun12/3.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_3'/></a>
<a href='#' onclick='load("4");'><img src='images/iitkgpmun12/4.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_4'/></a>
<a href='#' onclick='load("5");'><img src='images/iitkgpmun12/5.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_5'/></a>
<a href='#' onclick='load("6");'><img src='images/iitkgpmun12/6.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_6'/></a>
<a href='#' onclick='load("7");'><img src='images/iitkgpmun12/7.jpg' width='150px' height='125px' alt='IITKGPMUN_12_Pic_7'/></a>
</marquee>
<div class="entry">
<p>
IIT Kharagpur, being the first among the IITs, is not only known for its education but also its diverse extra-curricular activities and student initiatives. Spring Fest 2012, the social and cultural festival of the Institute, witnessed the maiden session of IIT Kharagpur Model United Nations Conference, jointly organized by the Debating Society and Spring Fest.
<br><br>
The Model UN Conference simulated two councils – the UN Security Council which deliberated over the turmoil in the South China Sea, and the Special Session of General Assembly set in the year 1947, discussing the future of Palestine once the British mandate is complete.
<br><br>
The three-day event gave rise to intense debate and the crisis situations put the delegates’ acumen to test. The countries were involved in talks and put forth rational resolutions to suppress the situations. The Press Conferences proved to be brain racking for the delegates and were the deciding factor for Best Delegate Awards. With over 80 participants and a wondrous Delegate Night, the inceptive MUN of IIT KGP was very successful and memorable for both the delegates and organizing committee alike.
</p>
</div>

</div>

</div>
<div id='lightBox' onclick='clse();' onkeydown="clseESC(event);">
	<div id='close' onclick='clse();'></div>
</div>
<div id='image'></div>
</div>
<?php include 'sidebar.php'; ?>