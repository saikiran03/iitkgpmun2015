<?php include_once('header.php'); ?>
<a href="key_dates.php">Key Dates</a>
</h2>
<div class="entry">
<p>
</p><table id="new_eb">
<tbody><tr>
<td>
Executive Board Applications:
</td>
<td>
Oct 12 - Oct 25, 2011.
</td>
</tr>
<tr>
<td>
Delegate applications (Priority Registrations):
</td>
<td>
Oct 26, 2011 onwards.
</td>
</tr>
<tr>
<td>
International Press applications:
</td>
<td>
Nov 1st, 2011 onwards.
</td>
</tr>
<tr>
<td>
Last Date for Online Payment and Ticket Confirmation:
</td>
<td>
Nov 25, 2011.
</td>
</tr>
<tr>
<td>
Last Date for the submission of position paper:
</td>
<td>
Jan 15, 2012.
</td>
</tr>
<tr>
<td>
Conference Dates:
</td>
<td>
Jan 21 to 23, 2012.
</td>
</tr>
</tbody></table>
<p></p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>