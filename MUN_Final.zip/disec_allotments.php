<?php include_once('header.php'); ?>
<a href="#">DISEC Allotments</a>
</h2>
<div class="entry">
	<p>Allotments will be out soon. Keep watching this space.</p>
	<!--
<div id="experience">
<table>
<tbody><tr>
<th>Country</th>
<th>Name</th>
<th>College</th>
</tr>
<tr>
<td>USA</td>
<td>Shouryendu Ray</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>Russia</td>
<td>Jaideep Sood</td>
<td>Symbiosis Law School Noida</td>
</tr>
<tr>
<td>China</td>
<td>Ahaan Mohan</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>France</td>
<td>Harish Vasudev</td>
<td>PSG Tech Coimbatore</td>
</tr>
<tr>
<td>UK</td>
<td>Jatin Gulati</td>
<td>SOL, Delhi University</td>
</tr>
<tr>
<td>Vietnam</td>
<td>Sourav Roy</td>
<td>NALSAR</td>
</tr>
<tr>
<td>Philippines</td>
<td>Sumit Kumar</td>
<td>Symbiosis Law School Pune</td>
</tr>
<tr>
<td>Iran</td>
<td>Abin Francis</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>Brazil</td>
<td>Pratik Tandon</td>
<td>SIMC Pune</td>
</tr>
<tr>
<td>Australia</td>
<td>Leela Krishna Nukkala</td>
<td>VIT</td>
</tr>
<tr>
<td>South Africa</td>
<td>Radhika Jagtap</td>
<td>Institute of Law, Nirma University</td>
</tr>
<tr>
<td>India</td>
<td>Mitsu Parikh</td>
<td>Institute of Law, Nirma University</td>
</tr>
<tr>
<td>Japan</td>
<td>Parashar Banarjee</td>
<td>Hidayatullah National Law University</td>
</tr>
<tr>
<td>Republic of Korea</td>
<td>Damini Agarwal</td>
<td>VIT</td>
</tr>
<tr>
<td>Venezuela</td>
<td>Rohan Chawla</td>
<td>KIRORI MAL COLLEGE, DELHI UNIVERSITY</td>
</tr>
<tr>
<td>Singapore (O)</td>
<td>Mohan Krishna</td>
<td>Presidency School, Bangalore South</td>
</tr>
<tr>
<td>Indonesia (O)</td>
<td>Prakhar Misra</td>
<td>MSRIT Bangalore</td>
</tr>
<tr>
<td>Malaysia (O)</td>
<td>Anubhuti Mishra</td>
<td>Hidayatullah National Law University</td>
</tr>
<tr>
<td>Thailand (O)</td>
<td>Aditya Agarwal</td>
<td>NIT Nagpur</td>
</tr>
<tr>
<td>Brunei (O)</td>
<td>Ivan Satch</td>
<td>NUJS Calcutta</td>
</tr>
</tbody></table>
</div>-->
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>