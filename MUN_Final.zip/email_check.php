<?php
if(isset($_POST['email'])) {
     
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "delegate.iitkgpmun@gmail.com";
    $email_subject = "Delegate Application";
     
     
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br/><br/>";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
     
    // validation expected data exists
    if(!isset($_POST['full_name']) ||
        !isset($_POST['gender']) ||
        !isset($_POST['course']) ||
        !isset($_POST['institute']) ||
        !isset($_POST['year']) ||
        !isset($_POST['place']) ||
        !isset($_POST['mobile']) ||
        !isset($_POST['email']) ||
        !isset($_POST['muns_as_delegate'])

        ) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
    }
     /*
    $full_name = $_POST['full_name']; // required
    $gender = $_POST['gender']; // required
    $course = $_POST['course']; // required
    $institute = $_POST['institute']; // required
    $year = $_POST['year']; // required
    $mobile = $_POST['mobile']; // required
    $email = $_POST['email']; // required
    $muns_as_delegate = $_POST['muns_as_delegate']; // not required
    $committee_1 = $_POST['committee_1']; // required
    $country_1_4 = $_POST['country_1_4']; // required
    $country_1_3 = $_POST['country_1_3']; // required
    $country_1_2 = $_POST['country_1_2']; // required
    $country_1_1 = $_POST['country_1_1']; // required
     */
	 extract($_POST);
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }
    $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$full_name)) {
    $error_message .= 'The Full Name you entered does not appear to be valid.<br />';
  }
  if(strlen($course) == 0) {
    $error_message .= 'The Course Name you entered does not appear to be valid.<br />';
  }
  if(!preg_match($string_exp,$institute)) {
    $error_message .= 'The Institute Name you entered does not appear to be valid.<br />';
  }
  if(!strlen($year) == 4 ) {
    $error_message .= 'The year you entered does not appear to be valid.<br />';
  }
  if(!strlen($mobile) == 10 ) {
    $error_message .= 'The mobile number you entered is not 10 digits in length.<br />';
  }
  $muns_as_delegate_exp = '/^[0-9]{1,}$/';
  if(strlen($muns_as_delegate) < 0 || !preg_match($muns_as_delegate_exp,$muns_as_delegate)) {
    $error_message .= 'The number of MUNs as delegates you entered does not appear to be valid.<br />';
  }
  $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$committee_1)) {
    $error_message .= 'The Committee Name you entered does not appear to be valid.<br />';
  }
  $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$country_1_4)) {
    $error_message .= 'The country 4 Name you entered does not appear to be valid.<br />';
  }
  $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$country_1_3)) {
    $error_message .= 'The country 3 Name you entered does not appear to be valid.<br />';
  }
  $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$country_1_2)) {
    $error_message .= 'The country 2 Name you entered does not appear to be valid.<br />';
  }
  $string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$country_1_1)) {
    $error_message .= 'The country 1 Name you entered does not appear to be valid.<br />';
  }
  if(strlen($error_message) > 0) {
    died($error_message);
  }
    $email_message = "Form details below.\n\n";
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
     /*
    $email_message .= "Full Name: ".clean_string($full_name)."\n";
    $email_message .= "Gender: ".clean_string($gender)."\n";
    $email_message .= "Course: ".clean_string($course)."\n";
    $email_message .= "Institue: ".clean_string($institue)."\n";
    $email_message .= "Year: ".clean_string($year)."\n";
    $email_message .= "Place: ".clean_string($place)."\n";
    $email_message .= "Mobile: ".clean_string($mobile)."\n";
    $email_message .= "Email: ".clean_string($email)."\n";
    $email_message .= "Number of muns os delegates: ".clean_string($muns_as_delegate)."\n";

    $email_message .= "Name of mun 1: ".clean_string($d_mun_1)."\n";  
    $email_message .= "Name of council 1: ".clean_string($d_council_1)."\n";   
    $email_message .= "Name of country 1: ".clean_string($d_country_1)."\n"; 
    $email_message .= "Name of award 1: ".clean_string($d_award_1)."\n";

    $email_message .= "Name of mun 2: ".clean_string($d_mun_2)."\n";  
    $email_message .= "Name of council 2: ".clean_string($d_council_2)."\n";   
    $email_message .= "Name of country 2: ".clean_string($d_country_2)."\n"; 
    $email_message .= "Name of award 2: ".clean_string($d_award_2)."\n"; 

    $email_message .= "Name of mun 3: ".clean_string($d_mun_3)."\n";  
    $email_message .= "Name of council 3: ".clean_string($d_council_3)."\n";   
    $email_message .= "Name of country 3: ".clean_string($d_country_3)."\n"; 
    $email_message .= "Name of award 3: ".clean_string($d_award_3)."\n"; 

    $email_message .= "Name of mun 4: ".clean_string($d_mun_1)."\n";  
    $email_message .= "Name of council 4: ".clean_string($d_council_1)."\n";   
    $email_message .= "Name of country 4: ".clean_string($d_country_1)."\n"; 
    $email_message .= "Name of award 4: ".clean_string($d_award_1)."\n";  

    $email_message .= "Name of mun 5: ".clean_string($d_mun_1)."\n";  
    $email_message .= "Name of council 5: ".clean_string($d_council_1)."\n";   
    $email_message .= "Name of country 5: ".clean_string($d_country_1)."\n"; 
    $email_message .= "Name of award 5: ".clean_string($d_award_1)."\n"; 

    $email_message .= "Committee_1: ".clean_string($committee_1)."\n";
    $email_message .= "Country_1_1: ".clean_string($country_1_1)."\n";
    $email_message .= "Country_1_2: ".clean_string($country_1_2)."\n";
    $email_message .= "Country_1_3: ".clean_string($country_1_3)."\n";
    $email_message .= "Country_1_4: ".clean_string($country_1_4)."\n";
     $email_message .= "Committee_2: ".clean_string($committee_2)."\n";
    $email_message .= "Country_2_1: ".clean_string($country_2_1)."\n";
    $email_message .= "Country_2_2: ".clean_string($country_2_2)."\n";
    $email_message .= "Country_2_3: ".clean_string($country_2_3)."\n";
    $email_message .= "Country_2_4: ".clean_string($country_2_4)."\n";
     */
    /*$sendgrid = new SendGrid('dheeraj2dj', '143DJ143');
$mail = new SendGrid\Mail();
$mail->
  addTo($email_to)->
  setFrom('iitkgpmun@gmail.com')->
  setSubject($email_subject)->
  setText($email_message);
$sendgrid->
smtp->
  send($mail);
  */
 //create email headers
/*$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
*/
	$mun_del_1= clean_string($d_mun_1).' , ';  
    $mun_del_1.= clean_string($d_council_1).' , ';   
    $mun_del_1.= clean_string($d_country_1).' , '; 
    $mun_del_1.= clean_string($d_awards_1)."\n";

    $mun_del_2 = clean_string($d_mun_2).' , ';  
    $mun_del_2 .= clean_string($d_council_2).' , ';   
    $mun_del_2 .= clean_string($d_country_2).' , '; 
    $mun_del_2 .= clean_string($d_awards_2)."\n"; 

    $mun_del_3 =clean_string($d_mun_3).' , ';  
    $mun_del_3 .= clean_string($d_council_3).' , ';   
    $mun_del_3 .= clean_string($d_country_3).' , '; 
    $mun_del_3 .= clean_string($d_awards_3)."\n"; 

    $mun_del_4 = clean_string($d_mun_4).' , ';  
    $mun_del_4 .= clean_string($d_council_4).' , ';   
    $mun_del_4 .= clean_string($d_country_4).' , '; 
    $mun_del_4 .= clean_string($d_awards_4)."\n";  

    $mun_del_5 = clean_string($d_mun_5).' , ';  
    $mun_del_5 .= clean_string($d_council_5).' , ';   
    $mun_del_5 .= clean_string($d_country_5).' , '; 
    $mun_del_5 .= clean_string($d_awards_5)."\n"; 
	
	$comm_1 = clean_string($committee_1).' , ';
	$comm_1 .= clean_string($country_1_1).' , ';
	$comm_1 .= clean_string($country_1_2).' , ';
	$comm_1 .= clean_string($country_1_3).' , ';
	$comm_1 .= clean_string($country_1_4)."\n";
	
	$comm_2 = clean_string($committee_2).' , ';
	$comm_2 .= clean_string($country_2_1).' , ';
	$comm_2 .= clean_string($country_2_2).' , ';
	$comm_2 .= clean_string($country_2_3).' , ';
	$comm_2 .= clean_string($country_2_4)."\n";
	
	$con = mysql_connect('173.193.206.138',"spring12",'simplyfantastic~12');
	
if (!$con) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("spring12_springfest2012",$con) or die(mysql_error());
$table='iitkgpmun13_del';
$ins="insert into `$table`(name,gender,course,institute,year,p_of_res,ph_no,email,no_mun_del,mun_del_1,mun_del_2,mun_del_3,mun_del_4,mun_del_5,del_exp,comm_1,comm_2) 
values('$full_name','$gender','$course','$institute','$year','$place','$mobile','$email','$muns_as_delegate','$mun_del_1','$mun_del_2','$mun_del_3','$mun_del_4','$mun_del_5','$mun_experience','$comm_1','$comm_2')";
$r=mysql_query($ins) or die(mysql_error);
?>
 
<!-- include your own success html here -->
 
Thank you for contacting us. We will be in touch with you very soon.
 
<?php
}
?>