<?php include_once('headerq.php'); ?>
<a href="#">Study Guides</a>
</h2>
<div class="entry">
<p>The Study Guides will be uploaded soon.</p>	
	<!--
<p>
<a href="http://iitkgpmun.springfest.in/unsc_study_guide.pdf" target="_blank">Click here to download the study guide for UN Security Council</a>
</p>
<p>
<a href="http://iitkgpmun.springfest.in/hga_study_guide.pdf" target="_blank">Click here to download the study guide for Historic General Assembly</a>
</p>-->
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>