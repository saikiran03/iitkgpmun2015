<?php include_once('header.php'); ?>
<a href="#">Public Relations</a>
</h2>
<br>
<br>
<br>
<p>
<b>
Director-EB and IP Affairs
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/15.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
A first year under-graduate in IIT Kharagpur, <b>Priyal</b> is currently pursuing a course in Quality Engineering, Design and Manufacturing. Apart from his keen interest in classic rock music and football, he is passionate about literature and poetry writing.
<div class="clr"></div>
</div>
<p>
<b>
Director-Delegate Affairs
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/13.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Nikhil</b>, is a fresher pursuing his M.Tech in Metallurgy. He has deep interest in Physics, and plans to pursue his interest. A very good dancer that he is, he also likes to play cricket at leisure. As the Director- Delegate Affairs, he’s taking active steps to ensure that the conference is a memorable experience for all the delegates.
<div class="clr"></div>
</div>



</div>
</div>
<?php include 'sidebar.php'; ?>