<?php include_once('header.php'); ?>
<a href="schedule.php">Schedule</a>
</h2>
<div class="entry">
<p>
The schedule of the conference will be updated in December, 2012.
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>