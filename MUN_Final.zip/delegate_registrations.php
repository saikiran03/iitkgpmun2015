<?php include_once('headerq.php'); ?>
<a href="#">Delegate Application Form</a>
</h2>
</div>
<p style="margin-left: 10px;">
<i>
In case of any error discovered after submitting the form, you can re-fill the entire form with the same email id that you used.
<br>
(*) marked fields are mandatory
</i>
</p>
<br>
<form accept-charset="UTF-8" action="email_check.php" class="new_delegate" id="new_delegate" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="c5k9wI58khA1X3X6ag7y6LRj/ipFBXVts30UVCQ3IJo=" type="hidden"></div>
<table id="new_eb">
<tbody><tr>
<td>
<b>Name *</b>
</td>
<td>
<input id="delegate_user_attributes_full_name" name="full_name" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Gender *</b>
</td>
<td>
<input id="delegate_user_attributes_gender_male" name="gender" value="Male" type="radio">
<label for="delegate_user_attributes_Male">Male</label>
<input id="delegate_user_attributes_gender_female" name="gender" value="Female" type="radio">
<label for="delegate_user_attributes_Female">Female</label>
</td>
</tr>
<tr>
<td>
<b>Course *</b>
</td>
<td>
<input id="delegate_user_attributes_course" name="course" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Institute *</b>
</td>
<td>
<input id="delegate_user_attributes_institute" name="institute" size="25" value="" type="text">
</td>
</tr>
<tr>
<td>
<b>Year *</b>
</td>
<td>
<input id="delegate_user_attributes_year" name="year" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Place of Residence *</b>
</td>
<td>
<input id="delegate_user_attributes_place_of_residence" name="place" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Mobile Number *</b>
</td>
<td>
<input id="delegate_user_attributes_mobile" name="mobile" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Email *</b>
</td>
<td>
<input id="delegate_user_attributes_email" name="email" size="25" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<br>
<b style="margin-left:10px;">
Previous Delegate Experience
</b>
<br>
<br>
<table id="new_eb">
<tbody><tr>
<td>
<b>Number of MUNs as Delegate *</b>
</td>
<td>
<input id="delegate_muns_as_delegate" name="muns_as_delegate" size="25" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<div id="experience">
<table style="margin-left:10px;">
<tbody><tr>
<th>Name of MUN</th>
<th>Council</th>
<th>Country</th>
<th>Awards (if any)</th>
</tr>
<tr>
<td>
<input id="delegate_d_mun_1" name="d_mun_1" size="15" type="text" value="0">
</td>
<td>
<input id="delegate_d_council_1" name="d_council_1" size="15" type="text">
</td>
<td>
<input id="delegate_d_country_1" name="d_country_1" size="15" type="text">
</td>
<td>
<input id="delegate_d_awards_1" name="d_awards_1" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="delegate_d_mun_2" name="d_mun_2" size="15" type="text">
</td>
<td>
<input id="delegate_d_council_2" name="d_council_2" size="15" type="text">
</td>
<td>
<input id="delegate_d_country_2" name="d_country_2" size="15" type="text">
</td>
<td>
<input id="delegate_d_awards_2" name="d_awards_2" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="delegate_d_mun_3" name="d_mun_3" size="15" type="text">
</td>
<td>
<input id="delegate_d_council_3" name="d_council_3" size="15" type="text">
</td>
<td>
<input id="delegate_d_country_3" name="d_country_3" size="15" type="text">
</td>
<td>
<input id="delegate_d_awards_3" name="d_awards_3" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="delegate_d_mun_4" name="d_mun_4" size="15" type="text">
</td>
<td>
<input id="delegate_d_council_4" name="d_council_4" size="15" type="text">
</td>
<td>
<input id="delegate_d_country_4" name="d_country_4" size="15" type="text">
</td>
<td>
<input id="delegate_d_awards_4" name="d_awards_4" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="delegate_d_mun_5" name="d_mun_5" size="15" type="text">
</td>
<td>
<input id="delegate_d_council_5" name="d_council_5" size="15" type="text">
</td>
<td>
<input id="delegate_d_country_5" name="d_country_5" size="15" type="text">
</td>
<td>
<input id="delegate_d_awards_5" name="d_awards_5" size="15" type="text">
</td>
</tr>
</tbody></table>
</div>
<br>
<br>
<b style="margin-left : 10px;">
Please Continue Writing Your MUN Experience as Delegate, Executive Board or International Press:
</b>
<br>
<br>
<textarea cols="40" id="delegate_mun_experience" name="mun_experience" rows="20" style="height:100px;width:810px;margin-left:10px"></textarea>
<br>
<br>
<br>
<br>
<br>
<br>
<p style="margin-left:10px;">
The applicants are advised to refer to the brief synopsis and country matrix of
<a href="http://springfest.in/iitkgpmun/disec.php" style="text-decoration:none;" target="_blank">DISEC</a>
and
<a href="http://springfest.in/iitkgpmun/historic_nato.php" style="text-decoration:none;" target="_blank">Historic NATO</a>
before applying.
</p>
<br>
<b style="margin-left:10px;">
Committee-Country Preference *
</b>
<br>
<br>
<div id="experience">
<table style="margin-left:10px;">
<tbody><tr>
<th>Committee *</th>
<th>Country 1 *</th>
<th>Country 2 *</th>
<th>Country 3 *</th>
<th>Country 4 *</th>
</tr>
<tr>
<td>
<input id="delegate_committee_1" name="committee_1" size="13" type="text">
</td>
<td>
<input id="delegate_country_1_1" name="country_1_1" size="13" type="text">
</td>
<td>
<input id="delegate_country_1_2" name="country_1_2" size="13" type="text">
</td>
<td>
<input id="delegate_country_1_3" name="country_1_3" size="13" type="text">
</td>
<td>
<input id="delegate_country_1_4" name="country_1_4" size="13" type="text">
</td>
</tr>
<tr>
<td>
<input id="delegate_committee_2" name="committee_2" size="13" type="text">
</td>
<td>
<input id="delegate_country_2_1" name="country_2_1" size="13" type="text">
</td>
<td>
<input id="delegate_country_2_2" name="country_2_2" size="13" type="text">
</td>
<td>
<input id="delegate_country_2_3" name="country_2_3" size="13" type="text">
</td>
<td>
<input id="delegate_country_2_4" name="country_2_4" size="13" type="text">
</td>
</tr>
</tbody></table>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<input id="delegate_submit" name="commit" value="Submit" type="submit">
<br>
<br>
</form>

</div>
<?php include 'sidebar.php'; ?>