<?php include_once('headerq.php'); ?>
<a href="#">International Press Application Form</a>
</h2>
</div>
<p style="margin-left:20px;">

International Press Applications will open soon.

</p>
<!--
<p style="margin-left: 10px;">
<i>
In case of any error discovered after submitting the form, you can re-fill the entire form with the same email id that you used.
<br>
(*) marked fields are mandatory
</i>
</p>
<br>
<form accept-charset="UTF-8" action="/international_press" class="new_international_press" id="new_international_press" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="c5k9wI58khA1X3X6ag7y6LRj/ipFBXVts30UVCQ3IJo=" type="hidden"></div>
<table id="new_eb">
<tbody><tr>
<td>
<b>Name *</b>
</td>
<td>
<input id="international_press_user_attributes_full_name" name="international_press[user_attributes][full_name]" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Gender *</b>
</td>
<td>
<input id="international_press_user_attributes_gender_male" name="international_press[user_attributes][gender]" value="Male" type="radio">
<label for="international_press_user_attributes_Male">Male</label>
<input id="international_press_user_attributes_gender_female" name="international_press[user_attributes][gender]" value="Female" type="radio">
<label for="international_press_user_attributes_Female">Female</label>
</td>
</tr>
<tr>
<td>
<b>Course *</b>
</td>
<td>
<input id="international_press_user_attributes_course" name="international_press[user_attributes][course]" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Institute *</b>
</td>
<td>
<input id="international_press_user_attributes_institute" name="international_press[user_attributes][institute]" size="25" value="none" type="text">
</td>
</tr>
<tr>
<td>
<b>Year *</b>
</td>
<td>
<input id="international_press_user_attributes_year" name="international_press[user_attributes][year]" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Place of Residence *</b>
</td>
<td>
<input id="international_press_user_attributes_place_of_residence" name="international_press[user_attributes][place_of_residence]" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Mobile Number *</b>
</td>
<td>
<input id="international_press_user_attributes_mobile" name="international_press[user_attributes][mobile]" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Email *</b>
</td>
<td>
<input id="international_press_user_attributes_email" name="international_press[user_attributes][email]" size="25" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<b style="margin-left: 10px;">
Previous International Press Experience
</b>
<br>
<br>
<table id="new_eb">
<tbody><tr>
<td>
<b>
Number of MUNs as International Press *
</b>
</td>
<td>
<input id="international_press_muns_as_ip" name="international_press[muns_as_ip]" size="25" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<div id="experience">
<table style="margin-left:10px;">
<tbody><tr>
<th>Name of MUN</th>
<th>Year of the MUN</th>
<th>News Agency</th>
<th>Position</th>
<th>Awards ( if any )</th>
</tr>
<tr>
<td>
<input id="international_press_ip_mun_1" name="international_press[ip_mun_1]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_year_1" name="international_press[ip_year_1]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_news_agency_1" name="international_press[ip_news_agency_1]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_position_1" name="international_press[ip_position_1]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_awards_1" name="international_press[ip_awards_1]" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="international_press_ip_mun_2" name="international_press[ip_mun_2]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_year_2" name="international_press[ip_year_2]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_news_agency_2" name="international_press[ip_news_agency_2]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_position_2" name="international_press[ip_position_2]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_awards_2" name="international_press[ip_awards_2]" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="international_press_ip_mun_3" name="international_press[ip_mun_3]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_year_3" name="international_press[ip_year_3]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_news_agency_3" name="international_press[ip_news_agency_3]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_position_3" name="international_press[ip_position_3]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_awards_3" name="international_press[ip_awards_3]" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="international_press_ip_mun_4" name="international_press[ip_mun_4]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_year_4" name="international_press[ip_year_4]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_news_agency_4" name="international_press[ip_news_agency_4]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_position_4" name="international_press[ip_position_4]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_awards_4" name="international_press[ip_awards_4]" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="international_press_ip_mun_5" name="international_press[ip_mun_5]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_year_5" name="international_press[ip_year_5]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_news_agency_5" name="international_press[ip_news_agency_5]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_position_5" name="international_press[ip_position_5]" size="15" type="text">
</td>
<td>
<input id="international_press_ip_awards_5" name="international_press[ip_awards_5]" size="15" type="text">
</td>
</tr>
</tbody></table>
</div>
<br>
<br>
<br>
<br>
<b style="margin-left : 10px;">
Please Continue Writing Your experience as International Press, Delegate or Executive Board:
</b>
<br>
<br>
<textarea cols="40" id="international_press_mun_experience" name="international_press[mun_experience]" rows="20" style="height:100px;width:810px;margin-left:10px"></textarea>
<br>
<br>
<br>
<p style="margin-left : 10px;">
Please refer to the brief overview and structure of our
<a href="http://iitkgpmun.springfest.in/ip" style="text-decoration: none;" target="_blank">International Press</a>
</p>
<br>
<table id="new_eb">
<tbody><tr>
<td>
<b>
Position Preference *
</b>
</td>
<td>
<select id="international_press_position_preference" name="international_press[position_preference]" style="width: 200px;height:30px;font-size:14px;"><option selected="selected" value="editor-in-chief">Editor-in-chief</option>
<option value="editor">Editor</option>
<option value="journalist">Journalist</option>
<option value="photographer">Photographer</option></select>
</td>
</tr>
</tbody></table>
<br>
<br>
<br>
<br>
<input id="international_press_submit" name="commit" style="width =&gt; 100px;height: 30px;font-size: 14px;" value="Submit" type="submit">
<br>
<br>
</form>-->

</div>
<?php include 'sidebar.php'; ?>