<?php include_once('header.php'); ?>
<a href="#">International Press</a>
</h2>
<br>
<br>
<br>
<p>
<b>
Director-International Press
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/5.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
A sophomore of the Department of Mechanical Engineering, <b>Arijit</b> is greatly interested in the debating activities on campus. Having seen  a few debating championships, he now looks forward to his first experience at an MUN. A Reporter for the campus newspaper, he is actively involved in numerous social endeavours and has a keen interest in emerging trends in engineering and technology.
<div class="clr"></div>
</div>
<div class="picture">
<img alt="" src="images/team/28.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
A fresher at IIT Kharagpur, <b>Rishal</b> has great interest in both debating and MUN's. With a keen interest in International Affairs and History, he adds value to our Press Corps. When not reading or debating, he can be found strumming on his guitar. As a member of the secretariat, he hopes that the MUN is a thrilling experience for him and all the participants 'content' wise.
<div class="clr"></div>
</div>



</div>
</div>
<?php include 'sidebar.php'; ?>