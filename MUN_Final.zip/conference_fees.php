<?php include_once('header.php'); ?>
<a href="http://iitkgpmun.springfest.in/conference_fees#">Conference Fees</a>
</h2>
<div class="entry">
<p>
<b>
For outstation delegates:
</b>
</p>
<p>
The conference fee includes the following:
</p><ul>
<li>
MUN Fees
</li>
<li>
Delegate Night
</li>
<li>
Star Nights of Spring Fest.
</li>
<li>
Accommodation
</li>
</ul>
<p></p>
<p>
The amount will be updated soon.
</p>
</div>
</div>

</div>
<?php include('sidebar.php') ?>