<?php include_once('header.php'); ?>
<a href="executive_board.php">Executive Board</a>
</h2>
<div class="entry">
<p>
With the DISEC and the Historic NATO deliberating over State-sponsored terrorism, and the Kosovo Conflict respectively, the conference will be a perfect platform and an exciting challenge for the most capable and experienced Executive Board members to chair the debates on these complex and hard-hitting world issues.
</p>
<p>
The Executive Board will also work closely with the Secretariat and the Crisis Simulation Team. Our EB structure consists of the following:
</p><ol>
<li>
<b>
DISEC:
<ul>
<li>
Chair
</li>
<li>
Vice Chair
</li>
<li>
Director
</li>
</ul>
</b>
</li>
<li>
<b>
Historic NATO:
<ul>
<li>
Chair
</li>
<li>
Vice Chair
</li>
<li>
Director
</li>
</ul>
</b>
</li>
</ol>
<p></p>
<p>
The remuneration for the Executive Board of each council is as follows:
</p><ul>
<li>
Chair: Rs 5000/-
</li>
<li>
Vice Chair: Rs 3000/-
</li>
<li>
Director: Rs 2000/-
</li>
</ul>
<p></p>
<p>
The Executive Board selection process is still underway.
<a href="executive_board_registrations.php">Click here to apply.</a>
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>