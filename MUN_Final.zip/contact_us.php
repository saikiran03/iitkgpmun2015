<?php include_once('headerq.php'); ?>
<a href="#">Contact Us</a>
</h2>
<div class="entry">
<p>
Thank you for showing interest in IIT Kharagpur Model United Nations 
Conference 2013. Our Team would be happy to not only answer any queries 
regarding the conference but also take valuable feedback from you to 
enhance your conference experience.
</p>
<p>
Feel free to drop us a mail anytime at iitkgpmun@gmail.com
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>