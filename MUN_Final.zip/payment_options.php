<?php include_once('headerq.php'); ?>
<a href="#">Payment Options</a>
</h2>
<div class="entry">
<p>
To be updated soon. Keep watching this space for more.
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>