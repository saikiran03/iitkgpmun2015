<?php include_once('header.php'); ?>
<a href="#">Administration</a>
</h2>
<br>
<br>
<br>
<p>
<b>
Director-Finance and Hospitality
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/12.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Nidhi</b> finished her high schooling in Gurgaon and is presently in her sophomore year, pursuing Economics in the Indian Institute of Technology, Kharagpur. She keeps a close watch on the domestic and world economy and envisages of turning around the economic identities of under-developed countries in future.<br>
An ambitious and diligent young girl, her thoughtful approach and integrity are vouched upon by her colleagues. She candidly confesses that she is ‘complicatedly simple’. Her friends are always confused if she is outgoing or self-contained. Either way, she is very receptive of everything that comes her way.<br> 
As the Director, Finance and Hospitality, she is here to deliver her best. While everyone promises you a memorable and exciting time at IIT Kharagpur Model United Nations Conference 2013, Nidhi is the one who’ll ensure it.<br>
<div class="clr"></div>
</div>
<p>
<b>
Director-Administration
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/9.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>

Pursuing his masters in Economics, <b>Manpreet</b> is what you call a chilled out man. When not making rhetorical speeches (much to the amusement of his friends), he likes to write poems. A reporter for the campus newsletter (Hindi), he likes keeping the mood light with his PJs ( though he fails miserably). Being a calm-headed person, he is the man to take charge of the administrative aspect of the conference.

<div class="clr"></div>
</div>
<p>
<b>
Director-Logistics
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/4.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Amrit</b> is currently a sophomore, pursuing a dual degree in Electronics and Electrical Communication at  IIT Kharagpur. When not engrossed in books, he can be found thematising debates in the foyer. A penchant for international affairs is what brings this cricket fanatic and moderately skilled painter to IITKGPMUN'13. As Director of Logistics he is committed to making it a hassle free MUN for everyone involved!
<div class="clr"></div>
</div>




</div>
</div>
<?php include 'sidebar.php'; ?>