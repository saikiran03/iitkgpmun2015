<?php include_once('headerq.php'); ?>
<a href="#">Historic NATO Allotments</a>
</h2>
<div class="entry">
	<p>Allotments will be out soon.Keep watching this space.</p>
	<!--
<div id="experience">
<table>
<tbody><tr>
<th>Country</th>
<th>Name</th>
<th>College</th>
</tr>
<tr>
<td>Jewish Agency (O)</td>
<td>Apurv Kumar Mishra</td>
<td>NLU Bhopal</td>
</tr>
<tr>
<td>Palestine AHC (O)</td>
<td>Unnati Walia</td>
<td>MBICEM Delhi</td>
</tr>
<tr>
<td>USA</td>
<td>Sarabjeet Singh</td>
<td>NLU Bhopal</td>
</tr>
<tr>
<td>UK</td>
<td>Siddhant Jaiswal</td>
<td>RMLNLU Lucknow</td>
</tr>
<tr>
<td>USSR</td>
<td>Debasis Bishoyi</td>
<td>SRMU</td>
</tr>
<tr>
<td>Rep. of China</td>
<td>Soumya Mohapatra</td>
<td>GIT Bhubaneswar</td>
</tr>
<tr>
<td>Afghanistan</td>
<td>Anand Upendran</td>
<td>National University of Advanced Legal Studies</td>
</tr>
<tr>
<td>Argentina</td>
<td>Yashaswini Basu</td>
<td>LSR College Delhi</td>
</tr>
<tr>
<td>Australia</td>
<td>Amarnath Reddy</td>
<td>SIT Pune</td>
</tr>
<tr>
<td>Belgium</td>
<td>Anupama Vijayakumar</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>Bolivia</td>
<td>Yashi Surana</td>
<td>Jadavpur University</td>
</tr>
<tr>
<td>Brazil</td>
<td>Aaron Michael</td>
<td>Anna University</td>
</tr>
<tr>
<td>Byelorussian SSR</td>
<td>Harshit Neotia</td>
<td>NALSAR</td>
</tr>
<tr>
<td>Canada</td>
<td>Wahid Hussain</td>
<td>Institute of Business Administration Dhaka</td>
</tr>
<tr>
<td>Chile</td>
<td>Akansha Singh</td>
<td>NLU Orissa</td>
</tr>
<tr>
<td>China</td>
<td>Yashwant Adiraju</td>
<td>CBIT Hyderabad</td>
</tr>
<tr>
<td>Colombia</td>
<td>Sourabh Sanyal</td>
<td>Orissa Engineering College Bhubaneswar</td>
</tr>
<tr>
<td>Costa Rica</td>
<td>Syed Ibrahim Saajid</td>
<td>Institute of Business Administration Dhaka</td>
</tr>
<tr>
<td>Cuba</td>
<td>Palak Jain</td>
<td>NLU Bhopal</td>
</tr>
<tr>
<td>Czechoslovakia</td>
<td>Mrinal Mohan</td>
<td>RGNLU</td>
</tr>
<tr>
<td>Denmark</td>
<td>Varun Tyagi</td>
<td>Galgotia College of Engineering &amp; Technology Noida</td>
</tr>
<tr>
<td>Dominican Republic</td>
<td>Md. Yazdani Ul Islam</td>
<td>Islamic University of Technology</td>
</tr>
<tr>
<td>Ecuador</td>
<td>Arif Nezami</td>
<td>United International University Bangladesh</td>
</tr>
<tr>
<td>Egypt</td>
<td>Chavali Sai Anisha</td>
<td>Manipal</td>
</tr>
<tr>
<td>El Salvador</td>
<td>Mythili Chandrashekhar</td>
<td>NLU Orissa</td>
</tr>
<tr>
<td>Ethiopia</td>
<td>Gagan Narang</td>
<td>NLU Orissa</td>
</tr>
<tr>
<td>France</td>
<td>Siddharth Uppal</td>
<td>VIT</td>
</tr>
<tr>
<td>Greece</td>
<td>Abhaya Panigrahi</td>
<td>College of Engineering and Technology Bhubaneswar</td>
</tr>
<tr>
<td>Guatemala</td>
<td>Earlis Dilbung</td>
<td>St. Stephen's College Delhi</td>
</tr>
<tr>
<td>Haiti</td>
<td>Kartikeya Pradhan</td>
<td>IIT Kharagpur</td>
</tr>
<tr>
<td>Honduras</td>
<td>Divya John</td>
<td>St. Stephen's College Delhi</td>
</tr>
<tr>
<td>Iceland</td>
<td>Mohammed Naser Ahmed Aziz</td>
<td>Shadan College of Engineering and Technology</td>
</tr>
<tr>
<td>India</td>
<td>Arya Chakrabarty</td>
<td>KIIT University Bhubaneswar</td>
</tr>
<tr>
<td>Iran</td>
<td>Mohammed Amer Abeddin</td>
<td>Shadan College of Engineering and Technology</td>
</tr>
<tr>
<td>Iraq</td>
<td>Vijayaraghavan</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>Lebanon</td>
<td>Saket Mani</td>
<td>SIT Pune</td>
</tr>
<tr>
<td>Liberia</td>
<td>Ushnish Chaudhuri</td>
<td>Sri Venkateswara College Delhi</td>
</tr>
<tr>
<td>Luxembourg</td>
<td>Nikhilesh Ravi</td>
<td>SRMU</td>
</tr>
<tr>
<td>Mexico</td>
<td>Devika Arora</td>
<td>Jaypee Institute of Information Technology Noida</td>
</tr>
<tr>
<td>Netherlands</td>
<td>Rishav Mishra</td>
<td>IIT Kharagpur</td>
</tr>
<tr>
<td>New Zealand</td>
<td>Pooja Singh</td>
<td>IIT Roorkee</td>
</tr>
<tr>
<td>Nicaragua</td>
<td>Arani Dhar</td>
<td>Asutosh College, Kolkata</td>
</tr>
<tr>
<td>Norway</td>
<td>Anvesha Kumar</td>
<td>RMLNLU Lucknow</td>
</tr>
<tr>
<td>Pakistan</td>
<td>Anisha Jain</td>
<td>SGSITS</td>
</tr>
<tr>
<td>Panama</td>
<td>Aditi Narayani</td>
<td>St. Stephen's College Delhi</td>
</tr>
<tr>
<td>Paraguay</td>
<td>Bhanu Tanwar</td>
<td>RGNLU Patiala</td>
</tr>
<tr>
<td>Peru</td>
<td>Subhrangsu Mukherjee</td>
<td>NIT Durgapur</td>
</tr>
<tr>
<td>Philippines</td>
<td>Ashwini Balasundaram</td>
<td>SRMU</td>
</tr>
<tr>
<td>Poland</td>
<td>Raj Dave</td>
<td>VNIT Nagpur</td>
</tr>
<tr>
<td>Saudi Arabia</td>
<td>Rachana Rautray</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>South Africa</td>
<td>Shalini Asija</td>
<td>Galgotia College of Engineering &amp; Technology Noida</td>
</tr>
<tr>
<td>Sweden</td>
<td>Anurag Saha</td>
<td>NIT Durgapur</td>
</tr>
<tr>
<td>Syria</td>
<td>Syed Asim</td>
<td>Shadan College of Engineering &amp; Technology Hyderabad</td>
</tr>
<tr>
<td>Thailand</td>
<td>Anirban Bhattacharya</td>
<td>Jadavpur University Calcutta</td>
</tr>
<tr>
<td>Turkey</td>
<td>Prachi Doshi</td>
<td>Jadavpur University Calcutta</td>
</tr>
<tr>
<td>Ukrainian SSR</td>
<td>Prateek Dash</td>
<td>ITER</td>
</tr>
<tr>
<td>Uruguay</td>
<td>Utkarsh Soni</td>
<td>NUJS Calcutta</td>
</tr>
<tr>
<td>Venezuela</td>
<td>Pallavi Prasad</td>
<td>LSR College Delhi</td>
</tr>
<tr>
<td>Yemen</td>
<td>Akash Pratap Singh</td>
<td>NLU Orissa</td>
</tr>
<tr>
<td>Yugoslavia</td>
<td>Abhishek Iyer</td>
<td>NLU Orissa</td>
</tr>
</tbody></table>
</div>-->
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>