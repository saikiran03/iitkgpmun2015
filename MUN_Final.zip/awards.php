<?php 
include_once('headerq.php');
 ?>
<a href="#">Awards</a>
</h2>
<div class="entry">
<p></p>
<p></p>
<div id="experience">
<table>
<tbody><tr>
<th>Delegate Awards</th>

</tr>
<tr>
<td>Best Delegate</td>

</tr>
<tr>
<td>High Commendation</td>

</tr>
<tr>
<td>Special Mention</td>

</tr>
<tr>
<td>Best Crisis Manager</td>

</tr>
<tr>
<td>Best Position Paper</td>

</tr>
</tbody></table>
</div>
<br>
<p>
Apart from these awards, the International Press will confer other informal titles. So suit up, and speak up!
</p>
<p>
<i style="font-size:11px;">
The awards mentioned here are tentative.
</i>
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>