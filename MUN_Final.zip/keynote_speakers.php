<?php include_once('header.php'); ?>
<a href="keynote_speaker.php">Keynote Speakers</a>
</h2>
<div class="entry">
<p>
At the IITKGPMUN, we hope to not only provide the delegates with the best possible conference experience but also an interactive session with those men and women who are at the pinnacle of their careers in international relations and foreign policy, as we believe that it is the ideal manner to obtain a first hand understanding of what it takes to be up there with the very best. With this view in mind, IITKGPMUN introduces the concept of keynote speakers to open the conference and give the delegates an insight into their methods, thoughts and way of life.
</p>
<p>
Keep watching this space for more.
</p>
</div>
</div>

</div>
<?php include 'sidebar.php'; ?>