<?php include_once('headerq.php'); ?>
<a href="#">Executive Board Application Form</a>
</h2>
</div>
<p style="margin-left: 10px;">
<i>
In case of any error discovered after submitting the form, you can re-fill the entire form with the same email id that you used.
<br>
(*) marked fields are mandatory
</i>
</p>
<br>
<form accept-charset="UTF-8" action="email_check_exec.php" class="new_executive_board" id="new_executive_board" method="post">
<!--<div style="margin:0;padding:0;display:inline"><input name="utf8" value="✓" type="hidden"><input name="authenticity_token" value="c5k9wI58khA1X3X6ag7y6LRj/ipFBXVts30UVCQ3IJo=" type="hidden"></div>-->
<table id="new_eb">
<tbody><tr>
<td>
<b>Name *</b>
</td>
<td>
<input id="executive_board_user_attributes_full_name" name="full_name" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Gender *</b>
</td>
<td>
<input id="executive_board_user_attributes_gender_male" name="gender" value="Male" type="radio">
<label for="executive_board_user_attributes_Male">Male</label>
<input id="executive_board_user_attributes_gender_female" name="gender" value="Female" type="radio">
<label for="executive_board_user_attributes_Female">Female</label>
</td>
</tr>
<tr>
<td>
<b>Course *</b>
</td>
<td>
<input id="executive_board_user_attributes_course" name="course" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Institute *</b>
</td>
<td>
<input id="executive_board_user_attributes_institute" name="institute" size="25" value="" type="text">
</td>
</tr>
<tr>
<td>
<b>Year *</b>
</td>
<td>
<input id="executive_board_user_attributes_year" name="year" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Place of Residence *</b>
</td>
<td>
<input id="executive_board_user_attributes_place_of_residence" name="place" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Mobile Number *</b>
</td>
<td>
<input id="executive_board_user_attributes_mobile" name="mobile" size="25" type="text">
</td>
</tr>
<tr>
<td>
<b>Email *</b>
</td>
<td>
<input id="executive_board_user_attributes_email" name="email" size="25" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<b style="margin-left: 10px;">
Previous Executive Board Experience
</b>
<br>
<br>
<table id="new_eb">
<tbody><tr>
<td>
<b>Numer of MUNs as Executive Board *</b>
</td>
<td>
<input id="executive_board_muns_as_eb" name="muns_as_eb" size="25" value="0" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<div id="experience">
<table style="margin-left:10px;">
<tbody><tr>
<th>Name of MUN</th>
<th>Year</th>
<th>Council</th>
<th>Position</th>
</tr>
<tr>
<td>
<input id="executive_board_eb_mun_1" name="eb_mun_1" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_year_1" name="eb_year_1" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_council_1" name="eb_council_1" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_position_1" name="eb_position_1" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_eb_mun_2" name="eb_mun_2" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_year_2" name="eb_year_2" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_council_2" name="eb_council_2" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_position_2" name="eb_position_2" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_eb_mun_3" name="eb_mun_3" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_year_3" name="eb_year_3" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_council_3" name="eb_council_3" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_position_3" name="eb_position_3" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_eb_mun_4" name="eb_mun_4" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_year_4" name="eb_year_4" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_council_4" name="eb_council_4" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_position_4" name="eb_position_4" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_eb_mun_5" name="eb_mun_5" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_year_5" name="eb_year_5" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_council_5" name="eb_council_5" size="15" type="text">
</td>
<td>
<input id="executive_board_eb_position_5" name="eb_position_5" size="15" type="text">
</td>
</tr>
</tbody></table>
</div>
<br>
<br>
<b style="margin-left : 10px;">
Please Continue Writing Your Executive Board Experience Here:
</b>
<br>
<br>
<textarea cols="40" id="executive_board_eb_experience" name="eb_experience" rows="20" style="height:100px;width:810px;margin-left:10px"></textarea>
<br>
<br>
<br>
<br>
<b style="margin-left:10px;">
Previous Delegate Experience
</b>
<br>
<br>
<table id="new_eb">
<tbody><tr>
<td>
<b>Numer of MUNs as Delegate *</b>
</td>
<td>
<input id="executive_board_muns_as_delegate" name="muns_as_delegate" size="25" value="0" type="text">
</td>
</tr>
</tbody></table>
<br>
<br>
<div id="experience">
<table style="margin-left:10px;">
<tbody><tr>
<th>Name of MUN</th>
<th>Council</th>
<th>Country</th>
<th>Awards (if any)</th>
</tr>
<tr>
<td>
<input id="executive_board_d_mun_1" name="d_mun_1" size="15" type="text">
</td>
<td>
<input id="executive_board_d_council_1" name="d_council_1" size="15" type="text">
</td>
<td>
<input id="executive_board_d_country_1" name="d_country_1" size="15" type="text">
</td>
<td>
<input id="executive_board_d_awards_1" name="d_awards_1" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_d_mun_2" name="d_mun_2" size="15" type="text">
</td>
<td>
<input id="executive_board_d_council_2" name="d_council_2" size="15" type="text">
</td>
<td>
<input id="executive_board_d_country_2" name="d_country_2" size="15" type="text">
</td>
<td>
<input id="executive_board_d_awards_2" name="d_awards_2" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_d_mun_3" name="d_mun_3" size="15" type="text">
</td>
<td>
<input id="executive_board_d_council_3" name="d_council_3" size="15" type="text">
</td>
<td>
<input id="executive_board_d_country_3" name="d_country_3" size="15" type="text">
</td>
<td>
<input id="executive_board_d_awards_3" name="d_awards_3" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_d_mun_4" name="d_mun_4" size="15" type="text">
</td>
<td>
<input id="executive_board_d_council_4" name="d_council_4" size="15" type="text">
</td>
<td>
<input id="executive_board_d_country_4" name="d_country_4" size="15" type="text">
</td>
<td>
<input id="executive_board_d_awards_4" name="d_awards_4" size="15" type="text">
</td>
</tr>
<tr>
<td>
<input id="executive_board_d_mun_5" name="d_mun_5]" size="15" type="text">
</td>
<td>
<input id="executive_board_d_council_5" name="d_council_5" size="15" type="text">
</td>
<td>
<input id="executive_board_d_country_5" name="d_country_5" size="15" type="text">
</td>
<td>
<input id="executive_board_d_awards_5" name="d_awards_5" size="15" type="text">
</td>
</tr>
</tbody></table>
</div>
<br>
<br>
<b style="margin-left : 10px;">
Please Continue Writing Your MUN Experience Here:
</b>
<br>
<br>
<textarea cols="40" id="executive_board_mun_experience" name="mun_experience" rows="20" style="height:100px;width:810px;margin-left:10px"></textarea>
<br>
<br>
<br>
<br>
<p style="margin-left:10px;">
<b>
Preferences:
</b>
</p>
<table id="new_eb">
<tbody><tr>
<td>
<b>
Council Preference *
</b>
</td>
<td>
<select id="executive_board_council_preference" name="council_preference">
<option selected="selected" value="historic nato">Historic NATO</option>
<option value="disec">DISEC</option></select>
</td>
</tr>
<tr>
<td>
<b>
Position Preference *
</b>
</td>
<td>
<select id="executive_board_position_preference" name="position_preference">
<option selected="selected" value="director">Director</option>
<option value="vice chair">Vice Chair</option>
<option value="chair">Chair</option></select>
</td>
</tr>
</tbody></table>
<br>
<br>
<br>
<br>
<input id="executive_board_submit" name="commit" value="Submit" type="submit">
<br>
<br>
</form>

</div>
<?php include 'sidebar.php'; ?>