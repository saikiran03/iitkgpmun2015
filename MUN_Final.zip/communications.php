<?php include_once('header.php'); ?>
<a href="#">Communications</a>
</h2>
<br>
<br>
<br>
<p>
<b>
Director-Off-line Publicity
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/20.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Suprad</b> is  a freshman at IIT Kharagpur. An aggressive and zealous debater, 
he can’t wait to witness the councils in action. Apart from being a passionate guitarist, he is also into athletics and swimming.
<div class="clr"></div>
</div>
<p>
<b>
Director-Online Publicity
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/8.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Manav</b> is a first year undergraduate student at IIT Kharagpur. Being a freshman, he has little experience, but great interest in both – debates and MUNs.He also enjoys an occasional game of tennis or squash, and likes to play the guitar. He follows cricket, soccer and motorsports like a typical sports fan. As a part of the secretariat, he hopes the IITKGPMUN will be a memorable experience, not just for himself, but also for all the delegates and participants.
<div class="clr"></div>
</div>
<p>
<b>
Director-Design
</b>
<br>
</p>
<div class="picture">
<img alt="" src="images/team/27.jpg" style="padding: 35px 30px 30px 20px;">
</div>
<div class="entry">
<p>
<b>Pranav</b> is a freshman pursuing his Master’s degree in Physics at IIT Kharagpur. A guy who is in love with physics and Feynman, he likes philosophy and logical thinking as well. When not busy solving complex equations, he can be found playing bench beats much to the annoyance (or pleasure?) of his classmates. He hopes to learn the nitty-gritties of an MUN Conference all the while adding value to the team as Director- Design.
<div class="clr"></div>
</div>


</div>
</div>
<?php include 'sidebar.php'; ?>